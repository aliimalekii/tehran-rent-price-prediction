# Project Status

- [x] Repository structure
- [x] Synthetic demo dataset
- [x] Data validation/cleaning
- [x] ML preprocessing pipeline
- [x] Random Forest regression model
- [x] Train/test split
- [x] MAE/RMSE/R² evaluation
- [x] Model persistence
- [x] FastAPI prediction endpoint
- [x] API tests
- [x] README
- [x] Interview guide
- [ ] Real Iranian dataset
- [ ] Real-data EDA
- [ ] Model comparison
- [ ] Hyperparameter tuning
- [ ] Explainability
- [ ] Frontend/demo deployment
