from typing import Dict

import pandas as pd

from .config import MODEL_PATH
from .model import load_model


def predict_rent(property_data: Dict) -> float:
    model = load_model(MODEL_PATH)
    row = pd.DataFrame([property_data])
    prediction = float(model.predict(row)[0])
    return round(prediction, 2)
