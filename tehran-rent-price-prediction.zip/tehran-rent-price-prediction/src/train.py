import argparse
import json

import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split

from .config import MODEL_PATH, TARGET
from .data import clean_data, load_data
from .model import build_pipeline, save_model


def train(use_sample: bool = False):
    df = clean_data(load_data(use_sample=use_sample))

    X = df.drop(columns=[TARGET])
    y = df[TARGET]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    pipeline = build_pipeline()
    pipeline.fit(X_train, y_train)

    predictions = pipeline.predict(X_test)

    metrics = {
        "mae_million_toman": round(float(mean_absolute_error(y_test, predictions)), 4),
        "rmse_million_toman": round(float(mean_squared_error(y_test, predictions) ** 0.5), 4),
        "r2": round(float(r2_score(y_test, predictions)), 4),
        "train_rows": int(len(X_train)),
        "test_rows": int(len(X_test)),
        "dataset_type": "synthetic_demo" if use_sample else "real",
    }

    save_model(pipeline, MODEL_PATH)

    metrics_path = MODEL_PATH.parent / "metrics.json"
    metrics_path.write_text(json.dumps(metrics, indent=2), encoding="utf-8")

    print(json.dumps(metrics, indent=2))
    print(f"Model saved to: {MODEL_PATH}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--sample",
        action="store_true",
        help="Train using the synthetic demo dataset.",
    )
    args = parser.parse_args()
    train(use_sample=args.sample)
