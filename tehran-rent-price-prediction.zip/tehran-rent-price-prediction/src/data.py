import pandas as pd

from .config import DATA_PATH, SAMPLE_DATA_PATH, TARGET, NUMERIC_FEATURES, CATEGORICAL_FEATURES


def load_data(use_sample: bool = False) -> pd.DataFrame:
    path = SAMPLE_DATA_PATH if use_sample else DATA_PATH
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found: {path}. "
            "Add the real dataset to data/raw/tehran_rent.csv "
            "or run with use_sample=True."
        )

    df = pd.read_csv(path)

    required = set(NUMERIC_FEATURES + CATEGORICAL_FEATURES + [TARGET])
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    return df


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    # Normalize obvious numeric fields.
    for col in NUMERIC_FEATURES + [TARGET]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    df["district"] = df["district"].astype("string").str.strip()

    # Basic validity rules.
    df = df.dropna(subset=NUMERIC_FEATURES + CATEGORICAL_FEATURES + [TARGET])
    df = df[df["area_sqm"] > 0]
    df = df[df[TARGET] > 0]
    df = df[df["bedrooms"].between(0, 8)]
    df = df[df["property_age"].between(0, 100)]
    df = df[df["floor"] >= 0]
    df = df[df["total_floors"] > 0]

    return df.reset_index(drop=True)
