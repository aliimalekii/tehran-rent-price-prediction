from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT_DIR / "data" / "raw" / "tehran_rent.csv"
SAMPLE_DATA_PATH = ROOT_DIR / "data" / "sample" / "synthetic_tehran_rent.csv"
MODEL_PATH = ROOT_DIR / "models" / "rent_model.joblib"

TARGET = "monthly_rent_million_toman"

NUMERIC_FEATURES = [
    "area_sqm", "bedrooms", "property_age", "floor",
    "total_floors", "elevator", "parking", "storage", "renovated"
]
CATEGORICAL_FEATURES = ["district"]
