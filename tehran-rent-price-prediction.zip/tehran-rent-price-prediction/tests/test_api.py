from fastapi.testclient import TestClient

from api.main import app

client = TestClient(app)


def test_root():
    response = client.get("/")
    assert response.status_code == 200
    assert response.json()["project"] == "Tehran Rent Price Prediction"


def test_prediction_requires_trained_model():
    payload = {
        "district": "District 5",
        "area_sqm": 80,
        "bedrooms": 2,
        "property_age": 6,
        "floor": 3,
        "total_floors": 5,
        "elevator": 1,
        "parking": 1,
        "storage": 1,
        "renovated": 0,
    }
    response = client.post("/predict", json=payload)
    assert response.status_code in (200, 503)
