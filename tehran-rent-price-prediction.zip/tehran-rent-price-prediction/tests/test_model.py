from src.model import build_pipeline


def test_pipeline_can_be_created():
    pipeline = build_pipeline()
    assert pipeline is not None
