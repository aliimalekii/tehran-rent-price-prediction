# Real Dataset

Place the real Tehran/Iran rental dataset here as:

`tehran_rent.csv`

Expected columns:

- district
- area_sqm
- bedrooms
- property_age
- floor
- total_floors
- elevator
- parking
- storage
- renovated
- monthly_rent_million_toman

The repository currently contains only a **synthetic demo dataset** for testing the code.
Do not present the synthetic results as real Tehran market results.
