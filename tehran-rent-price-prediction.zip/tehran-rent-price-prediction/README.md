# Tehran Rent Price Prediction

An end-to-end machine learning project for estimating residential rental prices in Tehran.

## Why this project?

Rental pricing is a practical problem in the Iranian housing market. The goal is to build a reproducible ML pipeline that takes property characteristics and estimates monthly rent.

The project is intentionally designed as an engineering + machine learning portfolio project, not just a notebook.

## Important data note

The repository currently contains a **synthetic demo dataset** so the code can be executed before the real dataset is collected.

**Synthetic results must not be interpreted as real Tehran market statistics.**

When a real dataset is available, place it at:

`data/raw/tehran_rent.csv`

The expected schema is documented in `data/raw/README.md`.

## Project pipeline

1. Load and validate data
2. Clean invalid/missing records
3. Split data into train/test sets
4. Preprocess numerical and categorical features
5. Train a Random Forest regression model
6. Evaluate with MAE, RMSE and R²
7. Save the trained pipeline
8. Expose predictions through a FastAPI endpoint

The preprocessing and model are kept inside a single scikit-learn Pipeline/ColumnTransformer so that the same transformations are applied during training and prediction.

## Features

- Tehran district
- Area in square meters
- Number of bedrooms
- Property age
- Floor
- Total floors
- Elevator
- Parking
- Storage
- Renovation status

## Target

`monthly_rent_million_toman`

## Run the project

### 1. Create a virtual environment

```bash
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
```

macOS/Linux:

```bash
source .venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Train with the synthetic demo data

```bash
python -m src.train --sample
```

This creates:

- `models/rent_model.joblib`
- `models/metrics.json`

### 4. Start the API

```bash
uvicorn api.main:app --reload
```

Then open:

`http://127.0.0.1:8000/docs`

FastAPI automatically provides interactive API documentation.

## Example API request

```json
{
  "district": "District 5",
  "area_sqm": 80,
  "bedrooms": 2,
  "property_age": 6,
  "floor": 3,
  "total_floors": 5,
  "elevator": 1,
  "parking": 1,
  "storage": 1,
  "renovated": 0
}
```

## Evaluation

The project uses:

- MAE — average absolute prediction error
- RMSE — penalizes larger errors more strongly
- R² — proportion of target variance explained by the model

Metrics generated from the synthetic dataset are only software-pipeline validation. They should not be reported as evidence of real Tehran market accuracy.

## Repository structure

```text
tehran-rent-price-prediction/
├── api/
│   └── main.py
├── data/
│   ├── raw/
│   │   └── README.md
│   └── sample/
│       └── synthetic_tehran_rent.csv
├── models/
├── notebooks/
├── reports/
├── src/
│   ├── config.py
│   ├── data.py
│   ├── model.py
│   ├── predict.py
│   └── train.py
├── tests/
├── .gitignore
├── requirements.txt
└── README.md
```

## Future improvements

- Replace synthetic data with a real Iranian rental dataset
- Add Persian neighborhood-level features
- Handle outliers using domain-specific rules
- Compare Linear Regression, Random Forest and Gradient Boosting
- Add hyperparameter tuning
- Add a web interface
- Add an "overpriced / fair / underpriced" decision layer
- Add model explainability with feature importance/SHAP
- Deploy the API

## Disclaimer

This project is for educational and portfolio purposes. A model trained on limited or synthetic data should not be used for financial or property investment decisions.
