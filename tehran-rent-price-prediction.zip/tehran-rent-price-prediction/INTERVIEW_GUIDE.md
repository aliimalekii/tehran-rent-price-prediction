# Interview Guide — Tehran Rent Price Prediction

## 1. What problem does the project solve?

It estimates monthly residential rent from property characteristics. The real-world motivation is to provide a data-driven baseline for comparing rental listings.

## 2. Why is this a regression problem?

The target is a continuous numeric value: monthly rent. Classification would be appropriate if the target were categories such as "cheap/fair/expensive".

## 3. Why use a train/test split?

The model should be evaluated on examples it did not see during training. This gives a more realistic estimate of generalization.

## 4. Why use a Pipeline?

A Pipeline keeps preprocessing and prediction together. It reduces the risk of applying different transformations during training and inference.

## 5. Why ColumnTransformer?

The dataset contains numerical features and a categorical feature (`district`). They need different preprocessing steps. ColumnTransformer lets us apply separate transformations and combine them into one feature space.

## 6. Why OneHotEncoder?

A model cannot directly use strings such as "District 5" as numeric input. One-hot encoding represents categories as binary indicator features.

## 7. Why Random Forest?

It is a strong baseline for tabular regression and can model nonlinear relationships and interactions between features without requiring us to manually specify a linear formula.

## 8. What is MAE?

Mean Absolute Error is the average absolute difference between predicted and actual values. If the target is measured in million toman, MAE is also expressed in million toman.

## 9. What is RMSE?

Root Mean Squared Error is the square root of the average squared prediction error. Because errors are squared before averaging, large errors receive more weight than with MAE.

## 10. What is R²?

R² measures how much of the variance in the target is explained by the model relative to a simple mean baseline. It should not be interpreted as "the model is X% accurate".

## 11. What is the biggest limitation right now?

The repository initially uses synthetic demo data. Real market conclusions require a properly collected, representative Iranian dataset and careful validation.

## 12. What would you improve next?

I would collect/clean a real Iranian rental dataset, compare multiple models, tune hyperparameters, investigate outliers, add location/neighborhood features, evaluate by district, and add explainability.

## 13. What should NOT be claimed in an interview?

Do not claim that the synthetic metrics represent real Tehran market accuracy.
Do not claim that the model can determine a property's true market value.
Do not claim production deployment unless it has actually been deployed.
