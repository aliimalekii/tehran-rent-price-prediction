from fastapi import FastAPI, HTTPException
import pandas as pd
from pydantic import BaseModel, Field

from src.config import MODEL_PATH
from src.model import load_model

app = FastAPI(
    title="Tehran Rent Price Prediction API",
    description="ML API for estimating monthly residential rent in Tehran.",
    version="1.0.0",
)


class PropertyInput(BaseModel):
    district: str = Field(..., examples=["District 5"])
    area_sqm: float = Field(..., gt=0, examples=[80])
    bedrooms: int = Field(..., ge=0, le=8, examples=[2])
    property_age: int = Field(..., ge=0, le=100, examples=[6])
    floor: int = Field(..., ge=0, examples=[3])
    total_floors: int = Field(..., gt=0, examples=[5])
    elevator: int = Field(..., ge=0, le=1, examples=[1])
    parking: int = Field(..., ge=0, le=1, examples=[1])
    storage: int = Field(..., ge=0, le=1, examples=[1])
    renovated: int = Field(..., ge=0, le=1, examples=[0])


class PredictionResponse(BaseModel):
    estimated_monthly_rent_million_toman: float
    note: str


def get_model():
    try:
        return load_model(MODEL_PATH)
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=503,
            detail="Model is not trained yet. Run: python -m src.train --sample",
        ) from exc


@app.get("/")
def root():
    return {
        "project": "Tehran Rent Price Prediction",
        "status": "running",
        "docs": "/docs",
    }


@app.post("/predict", response_model=PredictionResponse)
def predict(data: PropertyInput):
    model = get_model()
    row = pd.DataFrame([data.model_dump()])
    prediction = float(model.predict(row)[0])
    return PredictionResponse(
        estimated_monthly_rent_million_toman=round(prediction, 2),
        note="Estimate only. Replace the synthetic demo model with a real Iranian dataset before drawing market conclusions.",
    )
